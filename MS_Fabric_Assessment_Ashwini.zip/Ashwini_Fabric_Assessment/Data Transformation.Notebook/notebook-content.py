# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "545eee5a-d557-4e74-a388-b1dffd4945d6",
# META       "default_lakehouse_name": "LH_Fabricassessment",
# META       "default_lakehouse_workspace_id": "c58a8b59-f366-446c-a9af-5152c10ea5e7",
# META       "known_lakehouses": [
# META         {
# META           "id": "545eee5a-d557-4e74-a388-b1dffd4945d6"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Data transformation from Bronze to silver tables

# CELL ********************

from pyspark.sql.functions import col, to_timestamp, current_timestamp, year, month

df_erp_data = spark.read.table("bronze_erp_data")

#Adding created date column
df_erp_data_filtered = df_erp_data.withColumn("created_datetime", current_timestamp())

#Removing the records with missing values
df_erp_data_filtered = df_erp_data_filtered.filter(df_erp_data["category"].isNotNull())

table_name = "silver_erp_data"

df_erp_data_filtered.write.format("delta").mode("append").saveAsTable(table_name)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, to_timestamp, current_timestamp, year, month

df_crm_data = spark.read.table("bronze_crm_data")


#Adding created date column
df_crm_data_filtered = df_crm_data.withColumn("created_datetime", current_timestamp())

#Removing the records with missing values
df_crm_data_filtered = df_crm_data_filtered.filter(df_crm_data["contact_email"].isNotNull())

table_name = "silver_crm_data"

df_crm_data_filtered.write.format("delta").mode("append").saveAsTable(table_name)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

from pyspark.sql.functions import col, to_timestamp, current_timestamp, year, month

df_api_data = spark.read.table("bronze_api_data")

#Adding created date column
df_api_data_filtered = df_api_data.withColumn("created_datetime", current_timestamp())

table_name = "silver_api_data"

df_api_data_filtered.write.format("delta").mode("append").saveAsTable(table_name)

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
