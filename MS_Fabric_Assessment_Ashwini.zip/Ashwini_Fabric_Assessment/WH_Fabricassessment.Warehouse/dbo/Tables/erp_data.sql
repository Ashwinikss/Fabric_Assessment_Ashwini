CREATE TABLE [dbo].[erp_data] (

	[product_id] int NOT NULL, 
	[product_name] varchar(50) NULL, 
	[category] varchar(50) NOT NULL, 
	[price] decimal(18,0) NULL, 
	[stock_quantity] int NULL
);

