CREATE TABLE [dbo].[crm_data] (

	[Customer_id] int NOT NULL, 
	[customer_name] varchar(50) NULL, 
	[customer_email] varchar(50) NOT NULL, 
	[phone_number] varchar(50) NULL, 
	[purchase_date] date NULL, 
	[amount] decimal(18,0) NULL
);

