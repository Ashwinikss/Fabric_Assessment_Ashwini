CREATE TABLE [dbo].[api_data] (

	[id] int NOT NULL, 
	[name] varchar(50) NULL, 
	[latitude] decimal(18,0) NOT NULL, 
	[longitude] decimal(18,0) NOT NULL
);

