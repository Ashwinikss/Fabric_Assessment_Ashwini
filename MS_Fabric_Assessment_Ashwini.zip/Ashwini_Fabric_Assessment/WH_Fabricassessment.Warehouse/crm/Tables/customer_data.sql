CREATE TABLE [crm].[customer_data] (

	[customer_id] varchar(8000) NULL, 
	[customer_name] varchar(8000) NULL, 
	[contact_email] varchar(8000) NULL, 
	[phone_number] varchar(8000) NULL, 
	[purchase_date] varchar(8000) NULL, 
	[amount] varchar(8000) NULL
);

