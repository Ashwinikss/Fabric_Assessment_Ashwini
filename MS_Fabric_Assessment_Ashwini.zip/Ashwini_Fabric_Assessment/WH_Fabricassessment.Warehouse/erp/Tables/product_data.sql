CREATE TABLE [erp].[product_data] (

	[product_id] varchar(8000) NULL, 
	[product_name] varchar(8000) NULL, 
	[category] varchar(8000) NULL, 
	[price] varchar(8000) NULL, 
	[stock_quantity] varchar(8000) NULL
);

